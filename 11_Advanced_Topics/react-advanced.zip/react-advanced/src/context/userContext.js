import React from "react";

const UserContext = React.createContext();
UserContext.displayName = "UserContext";

export default UserContext;
