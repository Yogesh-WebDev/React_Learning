import React from "react";

const CartContext = React.createContext();
CartContext.displayName = "CartContext";

export default CartContext;
